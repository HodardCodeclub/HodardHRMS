$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+723247+'&oi='+133+'&ot=1&&url='+window.location, function(json){})    

});