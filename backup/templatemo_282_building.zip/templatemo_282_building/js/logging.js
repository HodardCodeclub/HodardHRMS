$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+541403+'&oi='+89+'&ot=1&&url='+window.location, function(json){})    

});